<?php
return [
    'businessbackup' => 'ທຸລະກິດສໍາຮອງຂໍ້ມູນ',
];