<?php
return [
    'businessbackup' => 'د سوداګرۍ بیک اپ',

];