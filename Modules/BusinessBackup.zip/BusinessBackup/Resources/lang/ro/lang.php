<?php
return [
    'businessbackup' => 'Backup pentru afaceri',
];