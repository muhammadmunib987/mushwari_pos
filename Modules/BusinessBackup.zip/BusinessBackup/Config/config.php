<?php

return [
    'name' => 'BusinessBackup',
    'module_version' => "1.0.0",
    'pid' => 19
];
