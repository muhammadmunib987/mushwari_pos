<?php

return [
    'name' => 'Backupadv',
    'module_version' => '0.1',
];
