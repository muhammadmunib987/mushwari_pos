<?php
return [
    'Backupadv_module' => 'النسخ الإحتياطي',
    'backup' => 'النسخ الاحتياطي',
    'upload_backup' => 'رفع نسخة احتياطية',
    'backup_logs' => 'سجل النسخ الاحتياطي',
];
