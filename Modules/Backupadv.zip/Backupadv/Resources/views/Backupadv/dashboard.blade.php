@extends('layouts.app')

@section('title', __('Backupadv::lang.Backupadv_module'))

@section('content')

	@include('Backupadv::layouts.nav')

@endsection