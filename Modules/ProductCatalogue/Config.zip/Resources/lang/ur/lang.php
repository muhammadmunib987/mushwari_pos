<?php

return [
    'productcatalogue_module' => 'پروڈکٹ کیٹلاگ ماڈیول',
    'catalogue_qr' => 'کیٹلاگ QR',
    'generate_qr' => 'QR تیار کریں',
    'select_business_location' => 'کاروباری مقام منتخب کریں',
    'download_image' => 'تصویر ڈاؤن لوڈ کریں',
    'qr_code_color' => 'QR کوڈ کا رنگ',
    'catalogue_instruction_1' => 'کاروباری مقام اور QR کوڈ کا رنگ منتخب کریں',
    'catalogue_instruction_2' => 'عنوان، ذیلی عنوان اور لوگو دکھانا یا نہیں منتخب کریں',
    'catalogue_instruction_3' => 'QR کوڈ تیار کرنے کے لیے کلک کریں',
    'product_catalogue' => 'پروڈکٹ کیٹلاگ',
    'show_business_logo_on_qrcode' => 'QR کوڈ پر کاروباری لوگو دکھائیں',
    'title' => 'عنوان',
    'subtitle' => 'ذیلی عنوان',
];
