<?php

return [
    'name' => 'ProductCatalogue',
    'module_version' => '1.0',
    'pid' => 8,
];
