<?php

namespace Modules\ProductCatalogue\Http\Controllers;

use App\Banner;
use App\Contact;
use App\Product;
use App\Business;
use App\Category;
use App\Discount;
use App\Variation;
use App\BusinessLocation;
use App\Utils\ModuleUtil;
use App\SellingPriceGroup;
use App\Utils\ProductUtil;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller;

class ProductCatalogueController extends Controller
{
    /**
     * All Utils instance.
     */
    protected $productUtil;

    protected $moduleUtil;

    /**
     * Constructor
     *
     * @param  ProductUtils  $product
     * @return void
     */
    public function __construct(ProductUtil $productUtil, ModuleUtil $moduleUtil)
    {
        $this->productUtil = $productUtil;
        $this->moduleUtil = $moduleUtil;
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index($business_id, $location_id)
    {
        $products = Product::where('business_id', $business_id)
                ->whereHas('product_locations', function ($q) use ($location_id) {
                    $q->where('product_locations.location_id', $location_id);
                })
                ->ProductForSales()
                ->with(['variations', 'variations.product_variation', 'category'])
                ->get()
                ->groupBy('category_id');
        $business = Business::with(['currency'])->findOrFail($business_id);
        $business_location = BusinessLocation::where('business_id', $business_id)->findOrFail($location_id);

        $now = \Carbon::now()->toDateTimeString();
        $discounts = Discount::where('business_id', $business_id)
                                ->where('location_id', $location_id)
                                ->where('is_active', 1)
                                ->where('starts_at', '<=', $now)
                                ->where('ends_at', '>=', $now)
                                ->orderBy('priority', 'desc')
                                ->get();
        foreach ($discounts as $key => $value) {
            $discounts[$key]->discount_amount = $this->productUtil->num_f($value->discount_amount, false, $business);
        }

        $categories = Category::forDropdown($business_id, 'product');

        $banners = Banner::where('business_id', $business_id)
        ->where('is_active', 1)
        ->orderBy('order', 'asc')
        ->get();

        // $cartItems = session()->get('cart', []);

        // session()->forget('cart');

    

        return view('productcatalogue::catalogue.index')->with(compact('products','banners','business', 'discounts', 'business_location', 'categories'));
    }


    public function addToCart(Request $request)
    {
        $request->validate([
            'variation_id' => 'required|exists:variations,id',
            'location_id' => 'required|exists:business_locations,id',
            'business_id' => 'required|exists:business,id',
            'name' => 'nullable',
            'image' => 'nullable',
        ]);
    
        $variation = Variation::find($request->variation_id);
    
        if (!$variation) {
            return response()->json([
                'status' => 'error',
                'message' => 'Invalid variation selected.'
            ], 400);
        }
    
        // Create a new cart item
        $cartItem = [
            'location_id' => $request->location_id,
            'name' => $request->name,
            'image' => $request->image,
            'variation_id' => $request->variation_id,
            'business_id' => $request->business_id,
            'quantity' => 1,
            'price' => $variation->sell_price_inc_tax
        ];
    
        // Retrieve the cart from the session
        $cart = session()->get('cart', []);
    
        // Check if item already exists in cart based on variation_id, location_id, and business_id
        $exists = false;
        foreach ($cart as $key => $item) {
            if ($item['variation_id'] == $cartItem['variation_id'] && $item['location_id'] == $cartItem['location_id'] && $item['business_id'] == $cartItem['business_id']) {
                // Item exists, increment the quantity
                $cart[$key]['quantity'] += 1;
                $exists = true;
                break;
            }
        }
    
        // If the item doesn't exist in the cart, add it
        if (!$exists) {
            $cart[] = $cartItem;
        }
    
        // Save the updated cart back to the session
        session()->put('cart', $cart);
    
        return response()->json([
            'status' => 'success',
            'message' => 'Product added to cart successfully!',
            'cart' => $cart
        ]);
    }
    
    

    public function updateCart(Request $request)
    {
        $variationId = $request->input('variation_id');
        $quantity = $request->input('quantity');
    
        $cart = session()->get('cart', []);
    
        foreach ($cart as $key => $item) {
            if ((int)$item['variation_id'] === (int)$variationId) {
                $cart[$key]['quantity'] = $quantity;
                break; 
            }
        }
    
        session()->put('cart', $cart);
    
        return response()->json(['message' => 'Cart updated successfully!']);
    }
    
    
    
    
    
    public function deleteCartItem(Request $request)
    {
        $variationId = $request->input('variation_id');
    
        $cart = session()->get('cart', []);
    
        foreach ($cart as $key => $item) {
            if ((int)$item['variation_id'] === (int)$variationId) {
                unset($cart[$key]);
                break;
            }
        }
    
        session()->put('cart', $cart);
    
        return response()->json(['message' => 'Item removed from the cart successfully!']);
    }
    

    public function viewCart($business_id, $location_id)
    {
        $business = Business::with(['currency'])->findOrFail($business_id);
        $business_location = BusinessLocation::where('business_id', $business_id)->findOrFail($location_id);
        $products=session()->get('cart', []);

        $total = 0;
    
        foreach ($products as $item) {
            $itemTotal = $item['price'] * $item['quantity']; 
    
            $total += $itemTotal;
        }
        return view('productcatalogue::catalogue.view')->with(compact('business','total','products','business_location'));
    }
    
    /**
     * Show the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($business_id, $id)
    {
        $product = Product::with(['brand', 'unit', 'category', 'sub_category', 'product_tax', 'variations', 'variations.product_variation', 'variations.group_prices', 'variations.media', 'product_locations', 'warranty'])->where('business_id', $business_id)
                        ->findOrFail($id);

        $price_groups = SellingPriceGroup::where('business_id', $product->business_id)->active()->pluck('name', 'id');

        $allowed_group_prices = [];
        foreach ($price_groups as $key => $value) {
            $allowed_group_prices[$key] = $value;
        }

        $group_price_details = [];
        $discounts = [];
        foreach ($product->variations as $variation) {
            foreach ($variation->group_prices as $group_price) {
                $group_price_details[$variation->id][$group_price->price_group_id] = $group_price->price_inc_tax;
            }

            $discounts[$variation->id] = $this->productUtil->getProductDiscount($product, $product->business_id, request()->input('location_id'), false, null, $variation->id);
        }

        $combo_variations = [];
        if ($product->type == 'combo') {
            $combo_variations = $this->productUtil->__getComboProductDetails($product['variations'][0]->combo_variations, $product->business_id);
        }

        return view('productcatalogue::catalogue.show')->with(compact(
            'product',
            'allowed_group_prices',
            'group_price_details',
            'combo_variations',
            'discounts'
        ));
    }


    public function contactSave(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'phone' => 'required|string|max:20',
            'business_id' => 'required', 
        ]);

        $existingContact = Contact::where('email', $validatedData['email'])->first();

        if ($existingContact) {
            return response()->json(['contact_id' => $existingContact->id]);
        } else {
            $contact = new Contact();
            $contact->name = $validatedData['name'];
            $contact->email = $validatedData['email'];
            $contact->mobile = $validatedData['phone'];
            $ref_count = $this->productUtil->setAndGetReferenceCount('contacts', $validatedData['business_id']);
            $contact->contact_id =$this->productUtil->generateReferenceNumber('contacts', $ref_count, $validatedData['business_id']);
            $contact->created_by=2;
            $contact->type='customer';
            $contact->business_id = $validatedData['business_id'];
            $contact->save();

            return response()->json(['contact_id' => $contact->id]);
        }

    }
    public function generateQr()
    {
        $business_id = request()->session()->get('user.business_id');
        if (! (auth()->user()->can('superadmin') || $this->moduleUtil->hasThePermissionInSubscription($business_id, 'productcatalogue_module'))) {
            abort(403, 'Unauthorized action.');
        }

        $business_id = request()->session()->get('user.business_id');
        $business_locations = BusinessLocation::forDropdown($business_id);
        $business = Business::findOrFail($business_id);

        return view('productcatalogue::catalogue.generate_qr')
                    ->with(compact('business_locations', 'business'));
    }
}
