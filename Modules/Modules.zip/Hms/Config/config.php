<?php

return [
    'name' => 'Hms',
    'module_version' => '2.0',
    'pid' => '18',
];
